from django.db import models

# Create your models here.

class memecatch(models.Model):
    id = models.AutoField(primary_key=True)
    sno = models.IntegerField()
    name = models.CharField(max_length=255)
    url1 = models.CharField(max_length=255)
    width = models.IntegerField()
    height = models.IntegerField()
    box_count = models.IntegerField()

    @property
    def __str__(self):
        return 'Message From ' + self.sno + ' - ' + self.name + ' - ' + self.url1

class memetab(models.Model):
    id = models.AutoField(primary_key=True)
    sno = models.IntegerField()
    name = models.CharField(max_length=255)
    url1 = models.CharField(max_length=255)
    width = models.IntegerField()
    height = models.IntegerField()
    box_count = models.IntegerField()

class sessiontab(models.Model):
    id = models.AutoField(primary_key=True)
    userid = models.IntegerField()
    sessionid = models.CharField(max_length=255)
    num_visits = models.IntegerField()
