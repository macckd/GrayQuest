# Declare Json library
import json
# Declare library for request
import requests
#from django.contrib.auth import authenticate, login, logout
from django.contrib.auth import authenticate, login as dj_login, logout
# library for message
from django.contrib import messages
from django.http import HttpResponse
# declare template render library
from django.shortcuts import render, redirect
# Declare model
from .models import memetab,sessiontab
# Create your views here.



def login(request):
    #Request for data from login form
    if request.method == 'POST':
        admsUsername = request.POST['admsUsername']
        admsPassword = request.POST['admsPassword']

        #Compare data from user authentication table
        user = authenticate(username=admsUsername ,password=admsPassword)

        # Condition to verify user credential
        if user is not None:
            dj_login(request, user)
            messages.success(request,"Successfully Logged In")
            return redirect('popup')
        else:
            messages.error(request, "Invalid Credentials, Please Try Again")
            return redirect('login')

    # Template rendering
    return render(request, 'home/login.html')

def handlelogout(request):
    logout(request)
    messages.success(request, "Successfully Logged Out")
    return redirect('login')

def popup(request):

    return render(request, 'home/popup.html')

def meme(request):
    # API program to find url
    url = "https://api.imgflip.com/get_memes"

    headers = {
        'cache-control': "no-cache",
        'postman-token': "c0536f34-64cd-d799-837d-168853fdceb5"
    }
    response = requests.request("GET", url, headers=headers)
    #json data load from responce
    data = json.loads(response.text)

    # find data from nested json
    dict1 = data["data"]['memes'][:]

    # Collect session details
    num_visits = request.session.get('num_visits', 1)
    userid = request.session.get('_auth_user_id')
    session_id = request.COOKIES['sessionid']
    #session_key = request.session._session_key
    request.session['num_visits'] = num_visits + 1

    # Store session in database table
    sessiondata = sessiontab(userid=userid, sessionid=session_id, num_visits=num_visits)
    sessiondata.save()

    #Delete record first and prevent from deadlock
    instance = memetab.objects.all()
    instance.delete()

    # for loop for data gather from Memes collection
    for dictionary in dict1:
        id = dictionary['id']
        name = dictionary['name']
        url1 = dictionary['url']
        width = dictionary['width']
        height = dictionary['height']
        box_count = dictionary['box_count']
        #print(id, name, url1, width, height, box_count)

        # save data into table
        created = memetab(sno=id, name=name, url1=url1, width=width, height=height, box_count=box_count)
        #save data into table
        created.save()

        # Display random data from database table memetab
        allPosts = memetab.objects.all().order_by('?')[:5]

        # collect data in one parameter
        context = {'allPosts': allPosts, 'num_visits': num_visits, 'userid':userid}

    # Template rendering and object parameter define
    return render(request, 'home/meme.html', context)


def search(request):
    #Get data from search form
    query = request.GET['query']

    # condition to check text length
    if len(query)>78:
        allPosts = memetab.objects.none()

    #allPosts = Post.objects.all()
    else:
        # Filter data using name and id
        allPostsname = memetab.objects.filter(name__icontains=query)
        allPostsid = memetab.objects.filter(id__icontains=query)

        # declare variable for union of two database field
        allPosts = allPostsname.union(allPostsid)

    # validate the data for result msg
    if allPosts.count() == 0:

        #message
        messages.warning(request, 'No Search Results Found. Please refine your query.')
    else:
        messages.success(request, 'Search Results Found. Please find your query.')

    params ={'allPosts': allPosts, 'query':query}
    return render(request, 'home/search.html', params)