from django.contrib import admin

# Register your models here.

from .models import memetab, sessiontab
from .models import memecatch

admin.site.register(memetab)
admin.site.register(memecatch)
admin.site.register(sessiontab)